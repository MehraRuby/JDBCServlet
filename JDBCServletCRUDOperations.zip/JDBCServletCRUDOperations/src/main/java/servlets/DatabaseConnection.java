package servlets;

import java.sql.*;


public class DatabaseConnection 
{
	public Connection connect() throws SQLException,ClassNotFoundException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","angad#18");  		
		return con;			
	}
	
}
