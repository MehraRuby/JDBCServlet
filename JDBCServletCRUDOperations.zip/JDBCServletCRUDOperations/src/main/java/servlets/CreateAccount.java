package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

@WebServlet("/CreateAccount")
public class CreateAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		// fetch data from form 
		
		String accnm = request.getParameter("accnm");
		Integer bal = Integer.parseInt(request.getParameter("bal"));
		
		try {
			DatabaseConnection db = new DatabaseConnection();
			Connection con = db.connect();
			PreparedStatement ps = con.prepareStatement("insert into account (account_holder_name,balance) values(?,?)");
			
			ps.setString(1, accnm);
			ps.setInt(2, bal);
			
			int i = ps.executeUpdate();
			
			// get back on main page 
			
			response.sendRedirect("index.jsp");
			
			
		} catch (ClassNotFoundException | SQLException e) {		
			e.printStackTrace();
		}
		
		
		
	}

}
